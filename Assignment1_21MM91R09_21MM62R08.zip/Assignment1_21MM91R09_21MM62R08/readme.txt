pip install -r requirements.txt
python Assignment1.py